#include <iostream>
#include <cstdlib>
#include <ctime>
#include <openacc.h>

#define N 5  // Matrix size

using namespace std;

void matrixMultiplicationCPU(float A[N][N], float B[N][N], float C[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            C[i][j] = 0;
            for (int k = 0; k < N; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void matrixMultiplicationOpenACC(float A[N][N], float B[N][N], float C[N][N]) {
    #pragma acc data copyin(A[0:N][0:N], B[0:N][0:N]) copyout(C[0:N][0:N])
    {
        #pragma acc parallel loop collapse(2)
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                float sum = 0;
                #pragma acc loop reduction(+:sum)
                for (int k = 0; k < N; k++) {
                    sum += A[i][k] * B[k][j];
                }
                C[i][j] = sum;
            }
        }
    }
}

void initializeMatrix(float matrix[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            matrix[i][j] = static_cast<float>(rand() % 10);  // Random values from 0-9
        }
    }
}

void printMatrix(const char* name, float matrix[N][N]) {
    cout << name << ":\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}

int main() {
    srand(time(0));

    // Declare matrices on heap for better OpenACC compatibility
    float (*A)[N] = new float[N][N];
    float (*B)[N] = new float[N][N];
    float (*C)[N] = new float[N][N];

    initializeMatrix(A);
    initializeMatrix(B);

    // Print input matrices
    printMatrix("Matrix A", A);
    printMatrix("Matrix B", B);

    cout << "Performing matrix multiplication using OpenACC...\n";
    matrixMultiplicationOpenACC(A, B, C);

    // Print output matrix
    printMatrix("Resultant Matrix C", C);

    // Free allocated memory
    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}
