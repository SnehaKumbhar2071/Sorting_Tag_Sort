#include <iostream>
#include <vector>

using namespace std;

// Function to perform LU Decomposition
void luDecomposition(vector<vector<double>>& A, vector<vector<double>>& L, vector<vector<double>>& U, int n) {
    // Initialize L and U as identity and zero matrices respectively
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j)
                L[i][j] = 1.0; // Diagonal elements of L are 1
            else
                L[i][j] = 0.0;
            U[i][j] = A[i][j]; // Copy A to U
        }
    }

    // Perform LU Decomposition
    for (int k = 0; k < n; k++) {
        // Update U
        for (int i = k + 1; i < n; i++) {
            if (U[k][k] == 0) {
                cout << "Error: Division by zero" << endl;
                return;
            }
            // Calculate multiplier for L
            L[i][k] = U[i][k] / U[k][k];

            // Update U[i]
            for (int j = k; j < n; j++) {
                U[i][j] -= L[i][k] * U[k][j];
            }
        }
    }
}

// Function to print a matrix
void printMatrix(vector<vector<double>>& mat, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int n = 3;  // Size of the matrix
    vector<vector<double>> A = {
        {4, -2, 1},
        {3, 6, -1},
        {2, 1, 3}
    };

    vector<vector<double>> L(n, vector<double>(n, 0)); // Lower triangular matrix
    vector<vector<double>> U(n, vector<double>(n, 0)); // Upper triangular matrix

    luDecomposition(A, L, U, n);

    cout << "Lower Triangular Matrix L:" << endl;
    printMatrix(L, n);

    cout << "Upper Triangular Matrix U:" << endl;
    printMatrix(U, n);

    return 0;
}