#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <cmath>
#include <ctime>

using namespace std;

struct Point {
    vector<double> features;
    int cluster;
};

vector<Point> loadCSV(const string &filename) {
    ifstream file(filename);
    vector<Point> data;
    string line;
    
    if(getline(file, line)) { }
    
    while(getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<double> features;
        int col = 0;
        while(getline(ss, token, ',')) {
            if(col < 4) {
                try {
                    features.push_back(stod(token));
                } catch (...) {
                }
            }
            col++;
        }
        data.push_back({features, -1});
    }
    return data;
}

double euclideanDistance(const vector<double> &a, const vector<double> &b) {
    double sum = 0;
    for (size_t i = 0; i < a.size(); i++) {
        sum += (a[i] - b[i]) * (a[i] - b[i]);
    }
    return sqrt(sum);
}

void kMeans(vector<Point> &points, int k, int maxIterations) {
    vector<vector<double>> centroids(k, vector<double>(points[0].features.size(), 0));
    for (int i = 0; i < k; i++) 
        centroids[i] = points[i].features;

    for (int iter = 0; iter < maxIterations; iter++) {
        // Assignment step
        for (auto &point : points) {
            double minDist = 1e9;
            for (int i = 0; i < k; i++) {
                double dist = euclideanDistance(point.features, centroids[i]);
                if (dist < minDist) {
                    minDist = dist;
                    point.cluster = i;
                }
            }
        }

        vector<vector<double>> newCentroids(k, vector<double>(points[0].features.size(), 0));
        vector<int> count(k, 0);
        for (const auto &point : points) {
            count[point.cluster]++;
            for (size_t j = 0; j < point.features.size(); j++) {
                newCentroids[point.cluster][j] += point.features[j];
            }
        }
        for (int i = 0; i < k; i++) {
            if (count[i] > 0) {
                for (size_t j = 0; j < newCentroids[i].size(); j++) {
                    newCentroids[i][j] /= count[i];
                }
            }
        }
        centroids = newCentroids;
    }
}

int main() {
    vector<Point> data = loadCSV("IRIS.csv");

    clock_t start = clock();
    kMeans(data, 3, 1000);
    clock_t end = clock();

    cout << "CPU:         " << double(end - start) / CLOCKS_PER_SEC << " seconds\n";
    return 0;
}
