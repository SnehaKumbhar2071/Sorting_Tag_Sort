#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define N 128  

void luDecomposition(float A[N][N], float L[N][N], float U[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            L[i][j] = 0;
            U[i][j] = 0;
        }
    }

    for (int i = 0; i < N; i++) {
        for (int k = i; k < N; k++) {
            float sum = 0;
            for (int j = 0; j < i; j++) {
                sum += (L[i][j] * U[j][k]);
            }
            U[i][k] = A[i][k] - sum;
        }

        for (int k = i; k < N; k++) {
            if (i == k)
                L[i][i] = 1;
            else {
                float sum = 0;
                for (int j = 0; j < i; j++) {
                    sum += (L[k][j] * U[j][i]);
                }
                L[k][i] = (A[k][i] - sum) / U[i][i];
            }
        }
    }
}

void printMatrix(float mat[N][N]) {
    int size = (N < 15) ? N : 15;  
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            printf("%8.4f ", mat[i][j]);
        }
        printf("\n");
    }
}

int main() {
    float A[N][N], L[N][N], U[N][N];

    srand(42);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            A[i][j] = (float)(rand() % 100) / 10.0;
        }
    }

    clock_t start = clock();
    luDecomposition(A, L, U);
    clock_t end = clock();
    double time_taken = ((double)(end - start)) * 1000000.0 / CLOCKS_PER_SEC;

    printf("Execution Time: %.0f microseconds\n", time_taken);
    printf("Original Matrix A :\n");
    printMatrix(A);
    printf("\nLower Triangular Matrix L :\n");
    printMatrix(L);
    printf("\nUpper Triangular Matrix U :\n");
    printMatrix(U);

    return 0;
}
