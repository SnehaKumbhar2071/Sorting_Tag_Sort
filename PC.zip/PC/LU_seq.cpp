#include <iostream>
#include <vector>
#include <chrono>
#include <iomanip>
#include <cmath>
#include <limits>

using namespace std;
using namespace std::chrono;

int main() {
    int n;
    cout << "Enter the size of the square matrix: ";
    cin >> n;

    vector<vector<double>> A(n, vector<double>(n));
    cout << "Enter the matrix elements row-wise:\n";
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            cin >> A[i][j];

    vector<vector<double>> L(n, vector<double>(n, 0.0));
    vector<vector<double>> U(n, vector<double>(n, 0.0));

    auto start = high_resolution_clock::now();

    // LU Decomposition
    for (int i = 0; i < n; i++) {
        // Upper Triangular
        for (int k = i; k < n; k++) {
            double sum = 0.0;
            for (int j = 0; j < i; j++)
                sum += L[i][j] * U[j][k];
            U[i][k] = A[i][k] - sum;
        }

        // Lower Triangular
        for (int k = i; k < n; k++) {
            if (i == k)
                L[i][i] = 1.0;
            else {
                double sum = 0.0;
                for (int j = 0; j < i; j++)
                    sum += L[k][j] * U[j][i];
                if (U[i][i] == 0) {
                    cerr << "Zero pivot encountered.\n";
                    return 1;
                }
                L[k][i] = (A[k][i] - sum) / U[i][i];
            }
        }
    }

    // Multiply L and U to validate the decomposition
    vector<vector<double>> LU(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            for (int k = 0; k < n; k++)
                LU[i][j] += L[i][k] * U[k][j];

    auto stop = high_resolution_clock::now();
    chrono::duration<double> duration = stop - start;

    // Output
    cout << "\nLower Triangular Matrix (L):\n";
    for (auto& row : L) {
        for (double val : row)
            cout << setw(12) << fixed << setprecision(6) << val;
        cout << endl;
    }

    cout << "\nUpper Triangular Matrix (U):\n";
    for (auto& row : U) {
        for (double val : row)
            cout << setw(12) << fixed << setprecision(6) << val;
        cout << endl;
    }

    cout << "\nMatrix multiplication of L and U:\n";
    for (auto& row : LU) {
        for (double val : row)
            cout << setw(12) << fixed << setprecision(6) << val;
        cout << endl;
    }

    cout << "\nRuntime: " << fixed << setprecision(6) << duration.count() << " seconds\n";

    return 0;
}
