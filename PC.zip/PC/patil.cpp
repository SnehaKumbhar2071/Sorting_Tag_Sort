#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
#include <ctime>

using namespace std;

// Function to fill matrix with random diagonal dominant values
void fillMatrix(double* a, int n)
{
    for (int i = 0; i < n * n; ++i)
    {
        a[i] = (rand() % 10) + 1;
    }

    int diagCount = 0;
    double sum = 0;
    for (int i = 0; i < n; ++i)
    {
        for (int j = i * n; j < i * n + n; ++j)
        {
            sum += abs(a[j]);
        }

        sum -= abs(a[i * n + diagCount]);
        a[i * n + diagCount] = sum + ((rand() % 5) + 1);
        ++diagCount;
        sum = 0;
    }
}

// Function to print matrix
void printMatrix(double* a, int n)
{
    for (int i = 0; i < (n * n); ++i)
    {
        if (i % n == 0)
            cout << endl << left << setw(9) << setprecision(3) << a[i] << left << setw(9);
        else
            cout << left << setw(9) << setprecision(3) << a[i] << left << setw(9);
    }
    cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
}

// Function to print 2D matrix
void print2D(double* matrix, int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << left << setw(9) << setprecision(3) << matrix[i * n + j] << left << setw(9);
        }
        cout << endl;
    }
}

// Function to perform LU Decomposition
void luDecomposition(double* a, double* l, double* u, int n)
{
    // Initialize L to identity matrix and U to the original matrix
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                l[i * n + j] = 1.0;
            else
                l[i * n + j] = 0.0;

            u[i * n + j] = a[i * n + j];
        }
    }

    // Perform LU Decomposition using Doolittle's method
    for (int k = 0; k < n; k++)
    {
        // Scale the pivot row
        for (int i = k + 1; i < n; i++)
        {
            l[i * n + k] = u[i * n + k] / u[k * n + k];  // for scaling row 'i' by pivot
            for (int j = k; j < n; j++)
            {
                u[i * n + j] -= l[i * n + k] * u[k * n + j];  // for row elimination step
            }
        }
    }
}

int main(int argc, char** argv)
{
    // Matrix dimension will be n*n
    int n = atoi(argv[1]);

    srand(1);

    // Allocate A matrix, L, and U for CPU (using 1D arrays)
    double* a = new double[n * n];
    double* l = new double[n * n];  // L will be a 1D array
    double* u = new double[n * n];  // U will be a 1D array

    // Fill matrix 'a' with diagonal dominant random values
    fillMatrix(a, n);

    // Start timer
    clock_t start_time = clock();

    // Perform LU Decomposition
    luDecomposition(a, l, u, n);

    // End timer
    clock_t end_time = clock();
    double runtime = double(end_time - start_time) / CLOCKS_PER_SEC;

    // Print results
    cout << "For " << n << " x " << n << " Matrix" << endl;
    cout << "Runtime for LU Decomposition is: " << runtime << " seconds" << endl;

    // Print matrices A, L, and U
    cout << "Matrix 'A' is:" << endl;
    printMatrix(a, n);
    cout << "Matrix 'L' is:" << endl;
    print2D(l, n);
    cout << "Matrix 'U' is:" << endl;
    print2D(u, n);

    // Free allocated memory
    delete[] a;
    delete[] l;
    delete[] u;

    return 0;
}
