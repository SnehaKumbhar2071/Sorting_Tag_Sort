#include <iostream>
#include <cstdlib>
#include <ctime>
#include <openacc.h>

using namespace std;

// Function to multiply two matrices A and B, storing the result in C
void matmul(int* A, int* B, int* C, int N) {
    #pragma acc parallel loop collapse(2) copyin(A[0:N*N], B[0:N*N]) copyout(C[0:N*N])
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            C[i * N + j] = 0;  // Flattened index calculation for C
            for (int k = 0; k < N; ++k) {
                C[i * N + j] += A[i * N + k] * B[k * N + j];
            }
        }
    }
}

// Function to initialize a matrix with random values
void initialize_matrix(int* matrix, int N) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            matrix[i * N + j] = rand() % 100;
        }
    }
}

// Function to print a matrix
void print_matrix(int* matrix, int N) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cout << matrix[i * N + j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int N = 512;  // Matrix size (N x N)
    
    // Seed the random number generator
    srand(time(0));

    // Allocate memory for matrices A, B, and C (using raw pointers)
    int* A = new int[N * N];
    int* B = new int[N * N];
    int* C = new int[N * N]();

    // Initialize matrices A and B with random values
    initialize_matrix(A, N);
    initialize_matrix(B, N);

    // Perform matrix multiplication with OpenACC
    matmul(A, B, C, N);

    // Optionally print the result matrix C
    // print_matrix(C, N);

    cout << "Matrix multiplication complete!" << endl;

    // Free allocated memory
    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}
