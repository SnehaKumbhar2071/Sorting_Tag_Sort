#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;

// Function to fill matrix with random values and make it diagonally dominant
void fillMatrix(double* a, int n) {
    for (int i = 0; i < n * n; ++i) {
        a[i] = (rand() % 10) + 1;
    }

    for (int i = 0; i < n; ++i) {
        double rowSum = 0.0;
        for (int j = 0; j < n; ++j) {
            if (j != i) {
                rowSum += abs(a[i * n + j]);
            }
        }
        a[i * n + i] = rowSum + (rand() % 5) + 1; // make it diagonally dominant
    }
}

// Function to print 1D matrix
void printMatrix(double* a, int n) {
    for (int i = 0; i < n * n; ++i) {
        if (i % n == 0) cout << endl;
        cout << left << setw(9) << setprecision(3) << a[i];
    }
    cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
}

// Function to print 2D matrix
void print2D(double** matrix, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            cout << left << setw(9) << setprecision(3) << matrix[i][j];
        }
        cout << endl;
    }
}

// LU decomposition (sequential)
void LU_Decomposition(double* A, double* L, double* U, int n) {
    for (int i = 0; i < n; i++) {
        // Upper Triangular
        for (int k = i; k < n; k++) {
            double sum = 0;
            for (int j = 0; j < i; j++) {
                sum += (L[i * n + j] * U[j * n + k]);
            }
            U[i * n + k] = A[i * n + k] - sum;
        }

        // Lower Triangular
        for (int k = i; k < n; k++) {
            if (i == k)
                L[i * n + i] = 1; // Diagonal as 1
            else {
                double sum = 0;
                for (int j = 0; j < i; j++) {
                    sum += (L[k * n + j] * U[j * n + i]);
                }
                L[k * n + i] = (A[k * n + i] - sum) / U[i * n + i];
            }
        }
    }
}

int main(int argc, char** argv) {
    if (argc < 3) {
        cout << "Usage: ./program <matrix_size> <print_flag (0 or 1)>" << endl;
        return 1;
    }

    int n = atoi(argv[1]);
    int printFlag = atoi(argv[2]);

    srand(1);
    double* A = new double[n * n];
    double* L = new double[n * n]{0};
    double* U = new double[n * n]{0};

    fillMatrix(A, n);

    clock_t start = clock();
    LU_Decomposition(A, L, U, n);
    clock_t end = clock();

    double elapsed = double(end - start) / CLOCKS_PER_SEC;

    if (printFlag == 1) {
        cout << "Original Matrix A:\n";
        printMatrix(A, n);

        cout << "\nMatrix L:\n";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                cout << left << setw(9) << setprecision(3) << L[i * n + j];
            cout << endl;
        }

        cout << "\nMatrix U:\n";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                cout << left << setw(9) << setprecision(3) << U[i * n + j];
            cout << endl;
        }
    }

    cout << fixed << setprecision(6);
    cout << "\nFor " << n << " x " << n << " Matrix\n";
    cout << "Runtime for LU Decomposition (sequential): " << elapsed << " seconds\n";

    delete[] A;
    delete[] L;
    delete[] U;

    return 0;
}
