# ✅ Install Required Libraries
# Run this command in your terminal if not installed:
# pip install spacy vaderSentiment bertopic sentence-transformers transformers pandas

import spacy
import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from bertopic import BERTopic
from transformers import pipeline

# 🔄 Loading NLP Models
print("\n🔄 Loading NLP models... (This may take a moment)")

try:
    nlp = spacy.load("en_core_web_lg")
    analyzer = SentimentIntensityAnalyzer()
    emotion_model = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", top_k=1)
    topic_model = BERTopic()
    print("✅ Models loaded successfully!\n")
except Exception as e:
    print(f"❌ Error loading models: {e}")
    exit(1)

# 📌 Sample Journal Entries
journals = [
    "I feel really anxious about my relationship. My partner is distant and I don’t know how to talk to them.",
    "Today, I learned about the importance of consent in a healthy relationship.",
    "I feel insecure about my body and my self-esteem is low.",
    "I had a great talk with my partner about boundaries, and it made me feel safe and respected.",
    "I’m struggling with my emotions and don’t know how to manage my anxiety.",
    "I finally had the confidence to say no in a situation I wasn't comfortable with."
]

# ✅ 1️⃣ Extract Emotion (Fixed)
def detect_emotion(text):
    try:
        result = emotion_model(text)  # Returns a list of lists
        if isinstance(result, list) and len(result) > 0:
            if isinstance(result[0], list) and len(result[0]) > 0:
                return result[0][0]['label']  # Correctly accessing the first dictionary
        return "Unknown"  # Default return if something goes wrong
    except Exception as e:
        print(f"❌ Error in emotion detection: {e}")
        return "Unknown"

# ✅ 2️⃣ Sentiment Analysis for Confidence
def get_confidence_score(text):
    sentiment = analyzer.polarity_scores(text)
    confidence = (sentiment["compound"] + 1) / 2  # Normalize between 0 and 1
    return round(confidence, 2)

# ✅ 3️⃣ Extract Topics Using BERTopic (Processes All Entries Together)
def extract_topics(journal_entries):
    try:
        topics, _ = topic_model.fit_transform(journal_entries)  # Fit on all entries
        topic_info = topic_model.get_topic_info()

        topic_names = {row["Topic"]: row["Name"] for _, row in topic_info.iterrows()}

        extracted_topics = []
        for topic in topics:
            extracted_topics.append(topic_names.get(topic, "General Reflection"))  # Default topic

        return extracted_topics
    except Exception as e:
        print(f"❌ Error in topic extraction: {e}")
        return ["General Reflection"] * len(journal_entries)  # Fallback

# ✅ 4️⃣ Generate Personalized Feedback
def generate_feedback(emotion, topic):
    feedback_dict = {
        "sadness": "It sounds like you're feeling down. Try some self-care activities.",
        "joy": "You're feeling great! Keep up the positive mindset!",
        "fear": "You might be feeling anxious. Deep breathing exercises can help.",
        "anger": "Try journaling your thoughts to process them in a healthy way.",
        "love": "Your relationships seem to be bringing you happiness!",
    }
    
    topic_suggestions = {
        "Consent": "Understanding consent is key to healthy relationships. Great job learning about it!",
        "Self-Esteem": "Building self-esteem takes time. Try daily affirmations!",
        "Relationships": "Healthy communication is important in relationships. Keep working on it!",
        "Boundaries": "It's amazing that you're setting boundaries. Keep advocating for yourself!",
        "Anxiety": "Managing anxiety can be tough. Have you tried meditation or journaling regularly?"
    }
    
    feedback = feedback_dict.get(emotion, "Keep writing! Reflecting on your thoughts is always helpful.")
    topic_feedback = topic_suggestions.get(topic, "")

    return f"{feedback} {topic_feedback}"

# 📌 Process Journal Entries & Store in Table
print("🔍 Processing journal entries...\n")
data = []

# Extract topics for all journal entries at once
topics = extract_topics(journals)

# Loop through each journal entry and analyze
for entry, topic in zip(journals, topics):
    emotion = detect_emotion(entry)
    confidence = get_confidence_score(entry)
    feedback = generate_feedback(emotion, topic)

    data.append({
        "Journal Entry": entry,
        "Detected Emotion": emotion,
        "Confidence Score": confidence,
        "Extracted Topic": topic,
        "Personalized Feedback": feedback
    })

# ✅ Convert to DataFrame & Display Results
df = pd.DataFrame(data)
print(df.to_string(index=False))

# 📌 Save to CSV (Optional)
df.to_csv("journal_analysis_results.csv", index=False)
print("\n✅ Analysis Complete! Results saved to journal_analysis_results.csv\n")
