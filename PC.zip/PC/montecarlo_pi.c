#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <openacc.h>

#define N 1000000  
int main() {
    int i, count = 0;
    double x, y, pi;

   
    srand(42);

    
    #pragma acc parallel loop reduction(+:count) private(x, y)
    for (i = 0; i < N; i++) {
        
        x = ((double)rand() / RAND_MAX);
        y = ((double)rand() / RAND_MAX);

        if (x * x + y * y <= 1.0) {
            count++;
        }
    }

    pi = 4.0 * count / N;

    printf("Estimated value of Pi: %f\n", pi);

    return 0;
}
