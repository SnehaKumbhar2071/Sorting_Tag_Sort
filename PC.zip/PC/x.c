#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <openacc.h>  // Make sure your compiler supports OpenACC

// Macro to index a 1D array as a 2D matrix element.
#define IDX(i, j, N) ((i) * (N) + (j))

// LU Decomposition (without pivoting) using contiguous memory arrays.
void lu_decomposition(float *A, float *L, float *U, int N) {
    int i, j, k;

    // Initialize L as the identity matrix and U as the zero matrix.
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            L[IDX(i, j, N)] = (i == j) ? 1.0f : 0.0f;
            U[IDX(i, j, N)] = 0.0f;
        }
    }

    // The outer loop must run sequentially due to data dependencies.
    for (k = 0; k < N; k++) {
        // Set the pivot in U.
        U[IDX(k, k, N)] = A[IDX(k, k, N)];

        // Offload the update of the k-th row of U and the k-th column of L.
        #pragma acc parallel loop present(A[0:N*N], L[0:N*N], U[0:N*N])
        for (j = k + 1; j < N; j++) {
            U[IDX(k, j, N)] = A[IDX(k, j, N)];
            L[IDX(j, k, N)] = A[IDX(j, k, N)] / A[IDX(k, k, N)];
        }

        // Wait for the first kernel to complete before updating the trailing submatrix.
        #pragma acc wait

        // Offload the update of the trailing submatrix.
        #pragma acc parallel loop collapse(2) present(A[0:N*N], L[0:N*N], U[0:N*N])
        for (i = k + 1; i < N; i++) {
            for (j = k + 1; j < N; j++) {
                A[IDX(i, j, N)] -= L[IDX(i, k, N)] * U[IDX(k, j, N)];
            }
        }

        // Wait for the trailing submatrix update to finish before next iteration.
        #pragma acc wait
    }
}

// Function to print a matrix stored as a 1D array.
void print_matrix(float *M, int N, const char *name) {
    printf("\n%s Matrix:\n", name);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%8.4f ", M[IDX(i, j, N)]);
        }
        printf("\n");
    }
}

int main() {
    int N;
    printf("Enter the size of the matrix (N x N): ");
    if (scanf("%d", &N) != 1) {
        fprintf(stderr, "Error reading matrix size.\n");
        return EXIT_FAILURE;
    }

    // Allocate contiguous memory for matrices A, L, and U.
    float *A = (float *)malloc(N * N * sizeof(float));
    float *L = (float *)malloc(N * N * sizeof(float));
    float *U = (float *)malloc(N * N * sizeof(float));
    if (!A || !L || !U) {
        fprintf(stderr, "Memory allocation failed!\n");
        return EXIT_FAILURE;
    }

    // Input matrix elements row by row.
    printf("Enter the matrix row by row (space-separated):\n");
    for (int i = 0; i < N; i++) {
        printf("Row %d: ", i);
        for (int j = 0; j < N; j++) {
            if (scanf("%f", &A[IDX(i, j, N)]) != 1) {
                fprintf(stderr, "Error reading element at (%d, %d).\n", i, j);
                return EXIT_FAILURE;
            }
        }
    }

    // Print the original matrix.
    printf("\nOriginal Matrix:");
    print_matrix(A, N, "Input");

    double start_time, end_time, elapsed_time;

    // Create an OpenACC data region so that all arrays reside on the device.
    // Use 'copy' so that the final values of A, L, and U are copied back to the host.
    #pragma acc data copy(A[0:N*N], L[0:N*N], U[0:N*N])
    {
        // Start timing.
        start_time = omp_get_wtime();

        // Perform LU decomposition.
        lu_decomposition(A, L, U, N);

        // Wait for any asynchronous kernels to finish.
        #pragma acc wait

        // End timing.
        end_time = omp_get_wtime();
        elapsed_time = end_time - start_time;
    }

    // Print the resulting L and U matrices.
    print_matrix(L, N, "L");
    print_matrix(U, N, "U");

    printf("\nExecution Time (OpenACC): %.6f seconds\n", elapsed_time);

    // Clean up allocated memory.
    free(A);
    free(L);
    free(U);

    return 0;
}
